function OnSubFb()
{
	ref = document.feedback;
	ref.URL.value = document.URL;
	if( ref.Message.value=="" )
		alert('Please enter your message');
	else
		ref.submit();
}
